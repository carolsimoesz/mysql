package com.example.mysql.activity

class LoginAluno {


}