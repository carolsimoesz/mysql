package com.example.mysql.model

data class Turma(
    val id: Int,
    val curso: String
)
