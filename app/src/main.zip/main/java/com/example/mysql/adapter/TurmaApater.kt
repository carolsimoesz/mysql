package com.example.mysql.adapter

class TurmaApater {

}